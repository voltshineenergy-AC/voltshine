"use client";
import {
  getMakes,
  getModels,
  getYears,
  getFuels,
} from "@/lib/vehicle";
import { useEffect, useState } from "react";

import type { VehicleData } from "@/types/vehicle";
export default function VehicleFinder() {
  const [selectedMake, setSelectedMake] = useState("");
const [selectedModel, setSelectedModel] = useState("");
const [selectedYear, setSelectedYear] = useState("");
const [selectedFuel, setSelectedFuel] = useState("");
const [makes, setMakes] = useState<string[]>([]);
const [models, setModels] = useState<string[]>([]);
const [years, setYears] = useState<number[]>([]);
const [fuels, setFuels] = useState<string[]>([]);
useEffect(() => {
  loadMakes();
}, []);

async function loadMakes() {
  const data = await getMakes();
  setMakes(data);
}
  return (
   <section className="relative -mt-40 z-20 pb-24">
      <div className="mx-auto max-w-6xl px-6">

        <div className="mb-8 text-center">
          <p className="text-sm font-semibold uppercase tracking-[6px] text-yellow-400">
            VEHICLE FINDER
          </p>

          <h2 className="mt-4 text-5xl font-bold text-white">
            Find Your Perfect Solution
          </h2>

          <p className="mt-4 text-lg text-gray-400">
            Select your vehicle and instantly check Battery,
            Windshield and Detailing services.
          </p>
        </div>

       <div className="rounded-[32px] border border-white/20 bg-white/10 backdrop-blur-3xl shadow-[0_25px_80px_rgba(0,0,0,0.65)] p-10 transition-all duration-500 hover:border-yellow-400/50 hover:shadow-[0_0_45px_rgba(255,193,7,0.25)]">

         <div className="grid gap-4 lg:grid-cols-5">

  className="h-14 rounded-2xl border border-white/10 bg-[#141414]/80 px-5 text-white outline-none transition-all duration-300 hover:border-yellow-400 focus:border-yellow-400"
 <select
  value={selectedMake}
  onChange={(e) => setSelectedMake(e.target.value)}
  className="h-14 rounded-2xl border border-white/10 bg-[#141414]/80 px-5 text-white outline-none transition-all duration-300 hover:border-yellow-400 focus:border-yellow-400"
>
  <option value="">Select Make</option>

  {makes.map((make) => (
    <option key={make} value={make}>
      {make}
    </option>
  ))}
</select>
</select>

           <select
  className="h-14 rounded-2xl border border-white/10 bg-[#141414]/80 px-5 text-white outline-none transition-all duration-300 hover:border-yellow-400 focus:border-yellow-400"
>
              <option>Select Model</option>
            </select>

            <select
  className="h-14 rounded-2xl border border-white/10 bg-[#141414]/80 px-5 text-white outline-none transition-all duration-300 hover:border-yellow-400 focus:border-yellow-400"
>
              <option>Select Year</option>
            </select>

           <select
  className="h-14 rounded-2xl border border-white/10 bg-[#141414]/80 px-5 text-white outline-none transition-all duration-300 hover:border-yellow-400 focus:border-yellow-400"
>
              <option>Select Fuel</option>
            </select>

            <button
  className="h-14 rounded-2xl bg-yellow-400 font-bold text-black transition-all duration-300 hover:scale-[1.03] hover:bg-yellow-300"
>
  Find My Solution
</button>

          </div>
        </div>

      </div>
    </section>
  );
}