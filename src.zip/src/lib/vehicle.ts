import { supabase } from "./supabase";

export async function getMakes() {
  const { data, error } = await supabase
    .from("vehicles")
    .select("make")
    .eq("status", true);

  if (error) throw error;

  return [...new Set(data.map((item) => item.make))].sort();
}

export async function getModels(make: string) {
  const { data, error } = await supabase
    .from("vehicles")
    .select("model")
    .eq("make", make)
    .eq("status", true);

  if (error) throw error;

  return [...new Set(data.map((item) => item.model))].sort();
}

export async function getYears(make: string, model: string) {
  const { data, error } = await supabase
    .from("vehicles")
    .select("from_year,to_year")
    .eq("make", make)
    .eq("model", model)
    .eq("status", true);

  if (error) throw error;

  const years = new Set<number>();

  data.forEach((row) => {
    for (let y = row.from_year; y <= row.to_year; y++) {
      years.add(y);
    }
  });

  return Array.from(years).sort((a, b) => b - a);
}

export async function getFuels(
  make: string,
  model: string,
  year: number
) {
  const { data, error } = await supabase
    .from("vehicles")
    .select("fuel")
    .eq("make", make)
    .eq("model", model)
    .lte("from_year", year)
    .gte("to_year", year)
    .eq("status", true);

  if (error) throw error;

  return [...new Set(data.map((item) => item.fuel))];
}